export interface ErrorResponse {
  message: any;
  timestamp: string;
}
